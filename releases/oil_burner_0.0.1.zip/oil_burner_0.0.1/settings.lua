--[[
	Part of the 'Oil burner' mod.
	
	Homepage: https://toxicantidote.net/
	Github: https://github.com/toxicantidote/
	
	See LICENSE.txt in the root mod folder for licensing details.
--]]

--[[ There are no settings, it just is --]]
