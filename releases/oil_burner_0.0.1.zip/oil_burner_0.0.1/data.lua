--[[
	Part of the 'Oil burner' mod.
	
	See LICENSE.txt in the root mod folder for licensing details.
--]]
require("prototypes.item")
require("prototypes.recipe")
require("prototypes.entity")
require("prototypes.technology")
